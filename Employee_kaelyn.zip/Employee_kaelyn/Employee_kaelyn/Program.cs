﻿using System;

class Program
{
   static double rate, hours, gross, deductions, net;//global variable 
    static int dependents; 

    static void GetData()
    {
       
        Console.Write("Hours worked: ");
        hours = double.Parse(Console.ReadLine());
        Console.Write("Hourly rate: ");
        rate = double.Parse(Console.ReadLine());
        Console.Write("Dependents: ");
        dependents = int.Parse(Console.ReadLine());
    }
   
  static void CalcNet()
    {
        if (hours <= 40)
            gross = Math.Round(hours * rate, 2);
        else
            gross = Math.Round((40 * rate + (hours - 40) * 1.5 * rate), 2);

        deductions = Math.Round(dependents * 25.50 + gross * 0.23, 2);
        net = Math.Round(gross - deductions, 2);
    }

    static void DspData()// definition 
    {
        Console.WriteLine("Hours Worked: " + hours);
        Console.WriteLine("Hourly Rate: " + rate.ToString("C"));
        Console.WriteLine("Dependents: " + dependents);
        Console.WriteLine("Gross Pay: " + gross.ToString("C"));
        Console.WriteLine("Deductions: " + deductions.ToString("C"));
        Console.WriteLine("Net Pay: " + net.ToString("C"));
    }

   static void Main()
    {
        GetData();//callling 
        CalcNet();
        DspData();
    }
}
